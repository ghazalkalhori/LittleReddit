export default function Comment({
    author = "-",
    time = "-",
    text = "-",
    likeNum = 0,
  }) {
    return (
     <div></div>
    );
  }
  